import java.util.ArrayList;

class FuelDispenser {
    private int fuelType;
    private ArrayList<Car> queue;
    private Car currentCar;
    private double serviceTimeRemaining;
    private int maxQueueLength;
    private boolean isBusy;
    private int dispenserX;
    private int dispenserY;
    private int number;

    public FuelDispenser(int fuelType, int maxQueueLength, int dispenserX, int dispenserY, int number) {
        this.fuelType = fuelType;
        this.maxQueueLength = maxQueueLength;
        this.dispenserX = dispenserX;
        this.dispenserY = dispenserY;
        this.number = number;
        this.queue = new ArrayList<Car>();
        this.currentCar = null;
        this.serviceTimeRemaining = 0.0;
        this.isBusy = false;
    }

    public int getFuelType() { return fuelType; }
    public ArrayList<Car> getQueue() { return queue; }
    public int getQueueLength() { return queue.size(); }
    public boolean canAcceptCar() { return queue.size() < maxQueueLength; }
    public void addCar(Car car) { if (canAcceptCar()) { queue.add(car); car.setState("queued"); } }
    public void update(double timeStep) {
        if (!isBusy && queue.size() > 0) {
            currentCar = queue.remove(0);
            serviceTimeRemaining = currentCar.getServiceTime();
            isBusy = true;
            currentCar.setState("serving");
        }
        if (isBusy && currentCar != null) {
            serviceTimeRemaining -= timeStep;
            currentCar.reduceServiceTime(timeStep);
            if (serviceTimeRemaining <= 0.0) {
                isBusy = false;
            }
        }
    }
    public boolean isBusy() { return isBusy; }
    public Car getCurrentCar() { return currentCar; }

    public int getDispenserX() { return dispenserX; }
    public int getDispenserY() { return dispenserY; }
    public int getNumber() { return number; }
}