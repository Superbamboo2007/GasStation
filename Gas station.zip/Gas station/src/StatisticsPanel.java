import javax.swing.*;
import java.awt.*;


class StatisticsPanel extends JPanel {
    private GasStation gasStation;
    private JTextArea statsArea;
    private Timer refreshTimer;

    public StatisticsPanel(GasStation gasStation) {
        this.gasStation = gasStation;
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createTitledBorder("Статистика"));
        setPreferredSize(new Dimension(350, 800));
        statsArea = new JTextArea();
        statsArea.setEditable(false);
        statsArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        add(new JScrollPane(statsArea), BorderLayout.CENTER);
        refreshTimer = new Timer(200, e -> updateDisplay());
        refreshTimer.start();
        updateDisplay();
    }

    public void updateDisplay() {
        StringBuilder sb = new StringBuilder();
        double currentTime = gasStation.getCurrentTimeInDay();
        int hours = (int)(currentTime / 60);
        int minutes = (int)(currentTime % 60);
        sb.append("ВРЕМЯ: ").append(String.format("%02d:%02d", hours, minutes)).append("\n");
        sb.append("ДЕНЬ ").append(gasStation.getDayNumber()).append("\n\n");

        sb.append("ДНЕВНАЯ СТАТИСТИКА\n");
        for (int i = 0; i < 3; i++) {
            sb.append(gasStation.getFuelNames().get(i)).append(":\n");
            sb.append(String.format("  Продано: %.1f л\n", gasStation.getDailySales(i)));
            sb.append(String.format("  Обслужено: %d машин\n", gasStation.getDailyServed(i)));
            sb.append(String.format("  Прибыль: %.2f руб\n", gasStation.getDailyProfit(i)));
            sb.append(String.format("  Наценка: %d%%\n", gasStation.getMarkup(i)));
            sb.append("\n");
        }

        sb.append("НЕДЕЛЬНАЯ СТАТИСТИКА\n");
        for (int i = 0; i < 3; i++) {
            sb.append(gasStation.getFuelNames().get(i)).append(":\n");
            sb.append(String.format("  Продано: %.1f л\n", gasStation.getWeeklySales(i)));
            sb.append(String.format("  Обслужено: %d машин\n", gasStation.getWeeklyServed(i)));
            sb.append(String.format("  Прибыль: %.2f руб\n", gasStation.getWeeklyProfit(i)));
            sb.append("\n");
        }

        sb.append("ОБЩАЯ СТАТИСТИКА\n");
        sb.append(String.format("Всего обслужено машин: %d\n", gasStation.getTotalServedCars()));
        sb.append(String.format("Потеряно клиентов: %d\n", gasStation.getTotalLostCars()));
        sb.append(String.format("Потеряно выручки: %.2f руб\n", gasStation.getTotalLostRevenue()));
        double totalProfit = gasStation.getWeeklyProfit(0) + gasStation.getWeeklyProfit(1) + gasStation.getWeeklyProfit(2);
        sb.append(String.format("Общая прибыль за неделю: %.2f руб\n", totalProfit));

        statsArea.setText(sb.toString());
    }
}