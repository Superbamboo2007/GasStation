import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ControlPanel extends JPanel {
    private GasStationSimulation simulation;
    private JButton startButton;
    private JButton pauseButton;
    private JButton resetButton;
    private JComboBox<String> fuelTypeCombo;
    private JTextField markupField;
    private JButton applyMarkupButton;

    public ControlPanel(GasStationSimulation simulation) {
        this.simulation = simulation;
        setLayout(new FlowLayout());
        setBorder(BorderFactory.createTitledBorder("Управление симуляцией"));

        startButton = new JButton("Старт");
        pauseButton = new JButton("Пауза");
        resetButton = new JButton("Сброс");

        startButton.addActionListener(e -> simulation.startSimulation());
        pauseButton.addActionListener(e -> simulation.pauseSimulation());
        resetButton.addActionListener(e -> simulation.resetSimulation());

        String[] fuelTypes = {"АИ-92", "АИ-95", "АИ-98"};
        fuelTypeCombo = new JComboBox<>(fuelTypes);

        markupField = new JTextField("10", 5);
        markupField.setHorizontalAlignment(JTextField.CENTER);

        applyMarkupButton = new JButton("Применить наценку");
        applyMarkupButton.addActionListener(e -> {
            try {
                int markup = Integer.parseInt(markupField.getText().trim());
                if (markup >= 5 && markup <= 15) {
                    int fuelType = fuelTypeCombo.getSelectedIndex();
                    simulation.setMarkup(markup, fuelType);
                    JOptionPane.showMessageDialog(ControlPanel.this,
                            "Наценка для " + fuelTypeCombo.getSelectedItem() + " установлена на " + markup + "%",
                            "Настройка наценки",
                            JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(ControlPanel.this,
                            "Наценка должна быть от 5 до 15%",
                            "Ошибка",
                            JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(ControlPanel.this,
                        "Введите целое число от 5 до 15",
                        "Ошибка",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        add(startButton);
        add(pauseButton);
        add(resetButton);
        add(new JLabel("Топливо:"));
        add(fuelTypeCombo);
        add(new JLabel("Наценка (%):"));
        add(markupField);
        add(applyMarkupButton);
    }
}