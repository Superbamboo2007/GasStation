import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class GasStationSimulation extends JFrame {
    private static int WIDTH = 1400;
    private static int HEIGHT = 800;

    private SimulationPanel simulationPanel;
    private ControlPanel controlPanel;
    private StatisticsPanel statisticsPanel;

    private GasStation gasStation;
    private Timer simulationTimer;

    private boolean isRunning;

    public GasStationSimulation() {
        setTitle("Бензозаправочная станция");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        gasStation = new GasStation(5, 7);
        simulationPanel = new SimulationPanel(gasStation);
        controlPanel = new ControlPanel(this);
        statisticsPanel = new StatisticsPanel(gasStation);

        add(simulationPanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);
        add(statisticsPanel, BorderLayout.EAST);

        simulationTimer = new Timer(16, new TimerAction());
        isRunning = false;

        setVisible(true);
    }

    private class TimerAction implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (isRunning) {
                gasStation.update();
                simulationPanel.repaint();
                statisticsPanel.updateDisplay();
            }
        }
    }

    public void startSimulation() {
        isRunning = true;
        simulationTimer.start();
    }

    public void pauseSimulation() {
        isRunning = false;
    }

    public void resetSimulation() {
        isRunning = false;
        gasStation.reset();
        simulationPanel.repaint();
        statisticsPanel.updateDisplay();
    }

    public void setMarkup(int percent, int fuelType) {
        gasStation.setMarkup(percent, fuelType);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new GasStationSimulation();
            }
        });
    }
}