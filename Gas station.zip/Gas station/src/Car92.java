class Car92 extends Car {
    public Car92(double maxFuelAmount) {
        super(maxFuelAmount);
        this.fuelType = 0;
    }

    public int getFuelType() {
        return 0;
    }
}