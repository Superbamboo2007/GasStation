abstract class Car {
    protected int fuelType;
    protected double fuelAmount;
    protected double maxFuelAmount;
    protected double serviceTime;
    protected double remainingServiceTime;
    protected int carId;
    private static int nextId = 1;
    protected double xPosition;
    protected double yPosition;
    protected String state;
    protected int targetDispenser;
    protected double targetX;
    protected double targetY;
    protected double speed;

    public Car(double maxFuelAmount) {
        this.maxFuelAmount = maxFuelAmount;
        this.fuelAmount = maxFuelAmount;
        this.serviceTime = 6.0 + (maxFuelAmount / 50.0) * 12.0;
        this.remainingServiceTime = this.serviceTime;
        this.carId = nextId;
        nextId++;
        this.xPosition = -100;
        this.yPosition = 400;
        this.state = "driving";
        this.targetDispenser = -1;
        this.speed = 3.5;
    }

    public void moveToTarget() {
        double dx = targetX - xPosition;
        double dy = targetY - yPosition;
        double distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < speed) {
            xPosition = targetX;
            yPosition = targetY;
        } else {
            double ratio = speed / distance;
            xPosition += dx * ratio;
            yPosition += dy * ratio;
        }
    }

    public abstract int getFuelType();

    public double getFuelAmount() { return fuelAmount; }
    public double getMaxFuelAmount() { return maxFuelAmount; }
    public double getServiceTime() { return serviceTime; }
    public double getRemainingServiceTime() { return remainingServiceTime; }
    public void reduceServiceTime(double delta) {
        this.remainingServiceTime -= delta;
        if (this.remainingServiceTime < 0) this.remainingServiceTime = 0;
    }
    public int getCarId() { return carId; }
    public double getXPosition() { return xPosition; }
    public void setXPosition(double x) { this.xPosition = x; }
    public double getYPosition() { return yPosition; }
    public void setYPosition(double y) { this.yPosition = y; }
    public String getState() { return state; }
    public void setState(String s) { this.state = s; }
    public int getTargetDispenser() { return targetDispenser; }
    public void setTargetDispenser(int d) { this.targetDispenser = d; }
    public double getTargetX() { return targetX; }
    public void setTargetX(double x) { this.targetX = x; }
    public double getTargetY() { return targetY; }
    public void setTargetY(double y) { this.targetY = y; }
    public static void resetId() { nextId = 1; }
}