import java.util.ArrayList;
import java.util.Random;

class GasStation {
    private ArrayList<FuelDispenser> dispensers;
    private ArrayList<Double> fuelPrices;
    private ArrayList<Double> fuelStock;
    private ArrayList<Integer> markups;
    private ArrayList<String> fuelNames;
    private ArrayList<Double> dailySales;
    private ArrayList<Integer> dailyServed;
    private ArrayList<Double> dailyProfit;
    private ArrayList<Double> weeklySales;
    private ArrayList<Integer> weeklyServed;
    private ArrayList<Double> weeklyProfit;
    private ArrayList<Car> activeCars;
    private Random random;
    private double timeStep;
    private double timeUntilNextCar;
    private int totalServedCars;
    private int totalLostCars;
    private double totalLostRevenue;
    private int dayNumber;
    private int weekNumber;
    private double currentTimeInDay;
    private double basePrice92;
    private double basePrice95;
    private double basePrice98;

    private int CAR_WIDTH = 120;
    private int MAX_QUEUE_LENGTH = 5;
    private int DISPENSER_HEIGHT = 100;
    private int FIRST_OFFSET = 120;
    private int STEP = CAR_WIDTH + 40;

    public GasStation(int numDispensers, int maxQueueLength) {
        dispensers = new ArrayList<FuelDispenser>();
        fuelPrices = new ArrayList<Double>();
        fuelStock = new ArrayList<Double>();
        markups = new ArrayList<Integer>();
        fuelNames = new ArrayList<String>();
        dailySales = new ArrayList<Double>();
        dailyServed = new ArrayList<Integer>();
        dailyProfit = new ArrayList<Double>();
        weeklySales = new ArrayList<Double>();
        weeklyServed = new ArrayList<Integer>();
        weeklyProfit = new ArrayList<Double>();
        activeCars = new ArrayList<Car>();
        random = new Random();

        basePrice92 = 45.0;
        basePrice95 = 50.0;
        basePrice98 = 55.0;
        fuelNames.add("АИ-92");
        fuelNames.add("АИ-95");
        fuelNames.add("АИ-98");

        for (int i = 0; i < 3; i++) {
            if (i == 0) fuelPrices.add(basePrice92);
            else if (i == 1) fuelPrices.add(basePrice95);
            else fuelPrices.add(basePrice98);
            fuelStock.add(10000.0);
            markups.add(10);
            dailySales.add(0.0);
            dailyServed.add(0);
            dailyProfit.add(0.0);
            weeklySales.add(0.0);
            weeklyServed.add(0);
            weeklyProfit.add(0.0);
        }

        int startX = 1150;
        int startY = 80;
        int verticalGap = 150;
        for (int i = 0; i < numDispensers; i++) {
            int fuelType = i % 3;
            int y = startY + i * verticalGap;
            dispensers.add(new FuelDispenser(fuelType, MAX_QUEUE_LENGTH, startX, y, i + 1));
        }

        timeStep = 0.016;
        timeUntilNextCar = 0;
        totalServedCars = 0;
        totalLostCars = 0;
        totalLostRevenue = 0;
        dayNumber = 1;
        weekNumber = 1;
        currentTimeInDay = 480;
    }

    private double generateArrivalTime() {
        double arrivalTime = 1.0 + random.nextDouble() * 2.5;
        double hour = currentTimeInDay / 60.0;
        if (hour >= 8 && hour <= 10) arrivalTime /= 2.5;
        if (hour >= 17 && hour <= 19) arrivalTime /= 2.5;
        if (hour >= 20 || hour <= 6) arrivalTime *= 2;
        if (arrivalTime < 0.5) arrivalTime = 0.5;
        if (arrivalTime > 4.0) arrivalTime = 4.0;
        return arrivalTime;
    }

    private Car generateCar() {
        int fuelType = random.nextInt(3);
        double maxFuelAmount = 10.0 + random.nextDouble() * 40.0;
        if (fuelType == 0) {
            return new Car92(maxFuelAmount);
        } else if (fuelType == 1) {
            return new Car95(maxFuelAmount);
        } else {
            return new Car98(maxFuelAmount);
        }
    }

    private void updateQueuePositions(FuelDispenser dispenser) {
        ArrayList<Car> queue = dispenser.getQueue();
        for (int i = 0; i < queue.size(); i++) {
            Car car = queue.get(i);
            if (car.getState().equals("queued")) {
                int queueX = dispenser.getDispenserX() - CAR_WIDTH - FIRST_OFFSET - i * STEP;
                int queueY = dispenser.getDispenserY() + DISPENSER_HEIGHT - 20;
                car.setTargetX(queueX);
                car.setTargetY(queueY);
            }
        }
    }

    private void balanceQueues() {
        for (int fuelType = 0; fuelType < 3; fuelType++) {
            ArrayList<FuelDispenser> typeDispensers = new ArrayList<FuelDispenser>();
            for (FuelDispenser d : dispensers) {
                if (d.getFuelType() == fuelType) typeDispensers.add(d);
            }
            if (typeDispensers.size() <= 1) continue;
            int minQueue = 999;
            int maxQueue = -1;
            FuelDispenser maxD = null;
            FuelDispenser minD = null;
            for (FuelDispenser d : typeDispensers) {
                int q = d.getQueueLength();
                if (q < minQueue) { minQueue = q; minD = d; }
                if (q > maxQueue) { maxQueue = q; maxD = d; }
            }
            if (maxQueue - minQueue > 2 && maxD != null && minD != null && maxD.getQueueLength() > 0) {
                Car carToMove = maxD.getQueue().remove(maxD.getQueue().size() - 1);
                minD.addCar(carToMove);
                updateQueuePositions(minD);
                updateQueuePositions(maxD);
            }
        }
    }

    public void update() {
        currentTimeInDay += timeStep * 10;
        if (currentTimeInDay >= 1440) {
            currentTimeInDay = 0;
            endDay();
            dayNumber++;
        }

        timeUntilNextCar -= timeStep;
        if (timeUntilNextCar <= 0.0) {
            Car newCar = generateCar();
            int bestDispenser = -1;
            int minQueue = 999;
            for (int i = 0; i < dispensers.size(); i++) {
                FuelDispenser d = dispensers.get(i);
                if (d.getFuelType() == newCar.getFuelType() && d.canAcceptCar()) {
                    int q = d.getQueueLength();
                    if (q < minQueue) { minQueue = q; bestDispenser = i; }
                }
            }
            if (bestDispenser != -1) {
                FuelDispenser target = dispensers.get(bestDispenser);
                newCar.setTargetDispenser(bestDispenser);
                newCar.setTargetX(target.getDispenserX() - CAR_WIDTH + 20);
                newCar.setTargetY(target.getDispenserY() + DISPENSER_HEIGHT - 20);
                newCar.setState("driving");
                newCar.setXPosition(-100);
                newCar.setYPosition(400);
                activeCars.add(newCar);
                target.addCar(newCar);
                updateQueuePositions(target);
            } else {
                double targetY = 850;
                newCar.setTargetDispenser(-1);
                newCar.setTargetX(1250);
                newCar.setTargetY(targetY);
                newCar.setState("bypass");
                newCar.setXPosition(-100);
                newCar.setYPosition(targetY);
                activeCars.add(newCar);
                totalLostCars++;
                double pricePerLiter = fuelPrices.get(newCar.getFuelType()) * (1.0 + markups.get(newCar.getFuelType()) / 100.0);
                double lostRevenue = newCar.getFuelAmount() * pricePerLiter;
                totalLostRevenue += lostRevenue;
            }
            timeUntilNextCar = generateArrivalTime();
        }

        for (Car car : activeCars) {
            String state = car.getState();
            if (state.equals("driving")) {
                car.moveToTarget();
                if (Math.abs(car.getXPosition() - car.getTargetX()) < 2 && Math.abs(car.getYPosition() - car.getTargetY()) < 2) {
                    car.setState("queued");
                    int td = car.getTargetDispenser();
                    if (td != -1) {
                        FuelDispenser target = dispensers.get(td);
                        ArrayList<Car> queue = target.getQueue();
                        for (int idx = 0; idx < queue.size(); idx++) {
                            if (queue.get(idx) == car) {
                                int queueX = target.getDispenserX() - CAR_WIDTH - FIRST_OFFSET - idx * STEP;
                                int queueY = target.getDispenserY() + DISPENSER_HEIGHT - 20;
                                car.setTargetX(queueX);
                                car.setTargetY(queueY);
                                break;
                            }
                        }
                    }
                }
            } else if (state.equals("queued")) {
                car.moveToTarget();
            } else if (state.equals("bypass")) {
                car.moveToTarget();
                if (Math.abs(car.getXPosition() - car.getTargetX()) < 2 && Math.abs(car.getYPosition() - car.getTargetY()) < 2) {
                    car.setState("leaving");
                    car.setTargetX(car.getXPosition() + 300);
                }
            } else if (state.equals("serving")) {
                int td = car.getTargetDispenser();
                if (td != -1) {
                    FuelDispenser target = dispensers.get(td);
                    car.setTargetX(target.getDispenserX() - CAR_WIDTH + 20);
                    car.setTargetY(target.getDispenserY() + DISPENSER_HEIGHT - 20);
                    car.moveToTarget();
                }
            } else if (state.equals("leaving")) {
                car.setTargetX(car.getXPosition() + 300);
                car.moveToTarget();
            }
        }

        for (int i = activeCars.size() - 1; i >= 0; i--) {
            Car car = activeCars.get(i);
            if (car.getState().equals("leaving") && car.getXPosition() > 1450) {
                int td = car.getTargetDispenser();
                if (td != -1) {
                    FuelDispenser d = dispensers.get(td);
                    d.getQueue().remove(car);
                    updateQueuePositions(d);
                }
                activeCars.remove(i);
            }
        }

        for (FuelDispenser d : dispensers) d.update(timeStep);

        for (FuelDispenser dispenser : dispensers) {
            Car servingCar = dispenser.getCurrentCar();
            if (servingCar != null && servingCar.getState().equals("serving") && !dispenser.isBusy()) {
                int fuelType = servingCar.getFuelType();
                double fuelAmount = servingCar.getFuelAmount();
                double price = fuelPrices.get(fuelType) * (1.0 + markups.get(fuelType) / 100.0);
                double profit = fuelAmount * (price - fuelPrices.get(fuelType));
                if (fuelStock.get(fuelType) >= fuelAmount) {
                    fuelStock.set(fuelType, fuelStock.get(fuelType) - fuelAmount);
                    dailySales.set(fuelType, dailySales.get(fuelType) + fuelAmount);
                    dailyServed.set(fuelType, dailyServed.get(fuelType) + 1);
                    dailyProfit.set(fuelType, dailyProfit.get(fuelType) + profit);
                    weeklySales.set(fuelType, weeklySales.get(fuelType) + fuelAmount);
                    weeklyServed.set(fuelType, weeklyServed.get(fuelType) + 1);
                    weeklyProfit.set(fuelType, weeklyProfit.get(fuelType) + profit);
                    totalServedCars++;
                }
                servingCar.setState("leaving");
                dispenser.getQueue().remove(servingCar);
                updateQueuePositions(dispenser);
            }
        }

        balanceQueues();
    }

    private void endDay() {
        for (int i = 0; i < 3; i++) {
            dailySales.set(i, 0.0);
            dailyServed.set(i, 0);
            dailyProfit.set(i, 0.0);
        }
        totalLostRevenue = 0;
        if (dayNumber % 7 == 0) {
            weekNumber++;
            for (int i = 0; i < 3; i++) {
                weeklySales.set(i, 0.0);
                weeklyServed.set(i, 0);
                weeklyProfit.set(i, 0.0);
            }
        }
    }

    public void reset() {
        for (FuelDispenser d : dispensers) d.getQueue().clear();
        activeCars.clear();
        for (int i = 0; i < 3; i++) {
            fuelStock.set(i, 10000.0);
            dailySales.set(i, 0.0);
            dailyServed.set(i, 0);
            dailyProfit.set(i, 0.0);
            weeklySales.set(i, 0.0);
            weeklyServed.set(i, 0);
            weeklyProfit.set(i, 0.0);
        }
        totalServedCars = 0;
        totalLostCars = 0;
        totalLostRevenue = 0;
        dayNumber = 1;
        weekNumber = 1;
        currentTimeInDay = 480;
        timeUntilNextCar = 0;
        Car.resetId();
    }

    public void setMarkup(int percent, int fuelType) {
        if (percent >= 5 && percent <= 15) markups.set(fuelType, percent);
    }

    public ArrayList<FuelDispenser> getDispensers() { return dispensers; }
    public ArrayList<Car> getActiveCars() { return activeCars; }
    public double getDailySales(int i) { return dailySales.get(i); }
    public int getDailyServed(int i) { return dailyServed.get(i); }
    public double getDailyProfit(int i) { return dailyProfit.get(i); }
    public double getWeeklySales(int i) { return weeklySales.get(i); }
    public int getWeeklyServed(int i) { return weeklyServed.get(i); }
    public double getWeeklyProfit(int i) { return weeklyProfit.get(i); }
    public int getTotalServedCars() { return totalServedCars; }
    public int getTotalLostCars() { return totalLostCars; }
    public double getTotalLostRevenue() { return totalLostRevenue; }
    public ArrayList<String> getFuelNames() { return fuelNames; }
    public int getMarkup(int i) { return markups.get(i); }
    public int getDayNumber() { return dayNumber; }
    public double getCurrentTimeInDay() { return currentTimeInDay; }

}