class Car98 extends Car {
    public Car98(double maxFuelAmount) {
        super(maxFuelAmount);
        this.fuelType = 2;
    }

    public int getFuelType() {
        return 2;
    }
}