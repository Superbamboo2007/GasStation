class Car95 extends Car {
    public Car95(double maxFuelAmount) {
        super(maxFuelAmount);
        this.fuelType = 1;
    }

    public int getFuelType() {
        return 1;
    }
}