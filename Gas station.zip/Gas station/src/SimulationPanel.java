import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

class SimulationPanel extends JPanel {
    private GasStation gasStation;
    private Timer refreshTimer;
    private ArrayList<Image> carImages;
    private Image dispenserImage;
    private Image backgroundImage;
    private boolean imagesLoaded;

    public SimulationPanel(GasStation gasStation) {
        this.gasStation = gasStation;
        setPreferredSize(new Dimension(1400, 800));

        carImages = new ArrayList<>();
        imagesLoaded = loadAllImages();

        refreshTimer = new Timer(100, e -> repaint());
        refreshTimer.start();
    }

    private boolean loadAllImages() {
        boolean ok = true;
        String[] carPaths = {"car92.png", "car95.png", "car98.png"};
        for (String path : carPaths) {
            try {
                BufferedImage img = ImageIO.read(new File(path));
                carImages.add(img);
            } catch (IOException e) {
                System.err.println("Не удалось загрузить картинку машины: " + path);
                carImages.add(null);
                ok = false;
            }
        }

        try {
            dispenserImage = ImageIO.read(new File("dispenser.png"));
        } catch (IOException e) {
            System.err.println("Не удалось загрузить картинку автомата: dispenser.png");
            dispenserImage = null;
            ok = false;
        }

        try {
            backgroundImage = ImageIO.read(new File("background.png"));
        } catch (IOException e) {
            System.err.println("Не удалось загрузить фоновую картинку: background.png");
            backgroundImage = null;
            ok = false;
        }
        return ok;
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        if (backgroundImage != null) {
            g2d.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), null);
        } else {
            g2d.setColor(new Color(180, 180, 190));
            g2d.fillRect(0, 0, getWidth(), getHeight());
        }

        drawDispensers(g2d);
        drawCars(g2d);
    }

    private void drawDispensers(Graphics2D g2d) {
        ArrayList<FuelDispenser> dispensers = gasStation.getDispensers();
        for (FuelDispenser d : dispensers) {
            int x = d.getDispenserX();
            int y = d.getDispenserY();

            if (dispenserImage != null) {
                g2d.drawImage(dispenserImage, x, y, 70, 100, null);
            } else {
                g2d.setColor(new Color(70, 130, 200));
                g2d.fillRoundRect(x, y, 70, 100, 12, 12);
                g2d.setColor(Color.BLACK);
                g2d.drawRoundRect(x, y, 70, 100, 12, 12);
            }

            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font("Arial", Font.BOLD, 16));
            g2d.drawString("" + d.getNumber(), x + 40, y + 28);

            String fuelName = d.getFuelType() == 0 ? "  92" : (d.getFuelType() == 1 ? "   95" : "   98");
            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font("Arial", Font.BOLD, 14));
            g2d.drawString(fuelName, x + 35, y + 75);

            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font("Arial", Font.PLAIN, 12));
            g2d.drawString("Очередь: " + d.getQueueLength(), x + 8, y + 128);
            if (d.getQueueLength() >= 5) {
                g2d.setColor(Color.RED);
                g2d.setFont(new Font("Arial", Font.BOLD, 10));
                g2d.drawString("ПЕРЕПОЛНЕНА", x + 8, y + 145);
            }
        }
    }

    private void drawCars(Graphics2D g2d) {
        ArrayList<Car> cars = gasStation.getActiveCars();
        for (Car car : cars) {
            int x = (int) car.getXPosition();
            int y = (int) car.getYPosition();
            int fuelType = car.getFuelType();
            if (x < -100 || x > 1450) continue;

            if (imagesLoaded && fuelType >= 0 && fuelType < carImages.size() && carImages.get(fuelType) != null) {
                Image img = carImages.get(fuelType);
                g2d.drawImage(img, x, y, 120, 70, null);
            } else {
                g2d.setColor(Color.RED);
                g2d.fillRoundRect(x, y, 120, 70, 12, 12);
                g2d.setColor(Color.BLACK);
                g2d.drawRoundRect(x, y, 120, 70, 12, 12);
                g2d.setColor(new Color(80, 80, 80));
                g2d.fillOval(x + 15, y + 50, 18, 18);
                g2d.fillOval(x + 85, y + 50, 18, 18);
                g2d.setColor(new Color(150, 200, 250));
                g2d.fillRect(x + 88, y + 10, 25, 30);
                g2d.setColor(Color.WHITE);
                g2d.fillRect(x + 15, y + 22, 40, 20);
            }

            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font("Arial", Font.PLAIN, 11));
            g2d.drawString("#" + car.getCarId(), x + 12, y + 28);
        }
    }
}